create view summary(course_id, title) as
SELECT course.course_id,
       course.title
FROM course;

alter table summary
    owner to postgres;

