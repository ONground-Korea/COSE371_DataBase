create view summary2(title, credits) as
SELECT course.title,
       course.credits
FROM course;

alter table summary2
    owner to postgres;

